package com.sample;

public class MovieTest {

	public static void main(String[] args) {
		Movie m1 = new Movie("Frozen", 109, 2013, "United States", 4.2);
		
		System.out.println("The movie has been review...");
		m1.director("Jennifer Lee and Chris Buck.");
		m1.portrayal("Fantasy and comedy.");
		System.out.println("Title: " + m1.getTitle());
		System.out.println("Duration in minutes: " + m1.getDuration());
		System.out.println("Year: " + m1.getYear());
		System.out.println("Country: " + m1.getCountry());
		System.out.println("Rate: " + m1.getRate());
	}
}
